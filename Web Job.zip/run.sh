﻿#!/bin/bash
# Run the WebJob executable
./EmailService
